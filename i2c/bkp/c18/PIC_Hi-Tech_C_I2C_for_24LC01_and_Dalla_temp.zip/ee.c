#include	<pic.h>
#include	"ee.h"

#define	SDA		GP1
#define	SCL		GP2
#define	TRUE	1
#define	FALSE	0
#define	WRITE_CONTROL_BYTE	0B10010000
#define	READ_CONTROL_BYTE	0B10010001
#define ACCESS_CONFIG		0xAC
#define START_TEMP_CONVERT	0x51
#define READ_TEMPERATURE	0xAA

extern byte ConfigError, ReadError;
/******************************************************************************/
/***                           24C01A routines                              ***/
/******************************************************************************/
/******************************************************************************/
/*Name          : ee_delay                                                    */
/*Description   : Dummy procedure that delays for eerom                       */
/*                                                                            */
/*Author        : Cameron Pearce                                              */
/*Date          : 24/08/98                                                    */
/*Version       : 1.0                                                         */
/*                                                                            */
/*Inputs        : none                                                        */
/*Outputs       : none                                                        */
/*Destroys      : nothing                                                     */
/*Globals       : none                                                        */
/*                                                                            */
/*Comments      :                                                             */
/*Uses          : a byte                                                      */
/******************************************************************************/
void ee_delay(void)
{byte delay;

 for(delay=0;delay<10;delay++);

}
/******************************************************************************/
/*Name          : ee_byte_to_ee                                               */
/*Description   : Places the dat byte at address in the EEROM                 */
/*                                                                            */
/*Author        : Cameron Pearce                                              */
/*Date          : 24/08/98                                                    */
/*Version       : 1.0                                                         */
/*                                                                            */
/*Inputs        : dat, the byte written                                       */
/*                address, the byte address of the data                       */
/*Outputs       : Returns True if write was successful                        */
/*Destroys      : nothing                                                     */
/*Globals       : none                                                        */
/*                                                                            */
/*Comments      :                                                             */
/*Uses          : nothing                                                     */
/******************************************************************************/
bit ee_byte_to_ee(byte address, byte dat)
{
/* Returns True if write was successfully acknowledged */
 ee_start();		 		/* Send start sequence */

 ee_byte(0xa0);          	/* Control byte (WRITE) */ 

 
 if (ack()) return(FALSE); 	/* Test Acknowledge	*/
 
 ee_byte(address);       	/* Address Byte */

 if (ack()) return(FALSE);

 ee_byte(dat);           	/* Data byte */

 if (ack()) return(FALSE);
 
 SCL=0;
 ee_delay(); 
 SDA=0;                  	/* Stop condition */
 TRIS1=0;		 		 	/* SDA OUTPUT     */
 ee_delay();
 SCL = 1;
 ee_delay();
 SDA = 1;
 ee_delay();
 return(TRUE);
}

/******************************************************************************/
/*Name          : ee_byte                                                     */
/*Description   : transmits the x byte to the eerom                           */
/*                                                                            */
/*Author        : Cameron Pearce                                              */
/*Date          : 25/08/98                                                    */
/*Version       : 1.0                                                         */
/*                                                                            */
/*Inputs        : x, the byte sent to the EEROM                               */
/*Outputs       : none                                                        */
/*Destroys      : nothing                                                     */
/*Globals       : none                                                        */
/*                                                                            */
/*Comments      :                                                             */
/*Uses          : 1 int                                                 	  */
/******************************************************************************/
void ee_byte(byte x)
{int i;

 i=0x80;
 do
  {
   SCL=0;
   TRIS1 =0;				/* SDA OUTPUT     */
   ee_delay();
   if (x&i) SDA=1;
    else SDA=0;
   ee_delay();
   SCL=1;
   ee_delay();
   i>>=1;
  }while(i!=0);
}
/******************************************************************************/
bit ack(void)
{ 
 SCL=0;                 /* Acknowledge 		*/
 ee_delay();
 TRIS1=1;				/* SDA Input		*/
 ee_delay();
 SCL=1;
 ee_delay();			/* Test Acknowledge	*/
 return(SDA);
}
/******************************************************************************/
/*Name          : ee_byte_from_ee                                             */
/*Description   : Gets a byte at address from the EEROM                       */
/*                                                                            */
/*Author        : Cameron Pearce                                              */
/*Date          : 25/08/98                                                    */
/*Version       : 1.0                                                         */
/*                                                                            */
/*Inputs        : dat, a pointer to the byte read                             */
/*                address, the byte address of the data                       */
/*Outputs       : Returns True if read was successful                         */
/*Destroys      : nothing                                                     */
/*Globals       : none                                                        */
/*                                                                            */
/*Comments      :                                                             */
/*Uses          : nothing                                                     */
/******************************************************************************/
bit ee_byte_from_ee(byte address,byte *dat)
{
/* Returns True if read was successfully acknowledged */
 
 ee_start();		 		/* Send start sequence */

 ee_byte(0xa0);          	/* Write Control byte */

 if (ack()) return(FALSE);

 ee_byte(address);       	/* Address Byte */

 if (ack()) return(FALSE);

 SCL=0;
 ee_delay();
 SCL=1;
 ee_delay();
 SDA=0;                  	/* Start Condition */
 TRIS1=0;		 			/* SDA OUTPUT	    */
 ee_delay();             

 ee_byte(0xa1);          /* Read Control byte */

 if (ack()) return(FALSE);

 ee_data(dat);           /* Get the data byte */
 
 ack();

 SCL=0;                  /* Stop condition */
 ee_delay();
 SDA=0;
 TRIS1=0;		 		/* SDA OUTPUT	    */
 ee_delay();
 SCL=1;
 ee_delay();
 SDA=1;
 return(TRUE);
}
/******************************************************************************/
/*Name          : ee_data                                                     */
/*Description   : receives a byte from the eerom                              */
/*                                                                            */
/*Author        : Cameron Pearce                                              */
/*Date          : 27/08/98                                                    */
/*Version       : 1.0                                                         */
/*                                                                            */
/*Inputs        : x, a pointer to the byte received                           */
/*Outputs       : none                                                        */
/*Destroys      : nothing                                                     */
/*Globals       : none                                                        */
/*                                                                            */
/*Comments      :                                                             */
/*Uses          : 1 int                                                 	  */
/******************************************************************************/
void ee_data(byte *x)
{int i;

 TRIS1=1;		/* SDA INPUT */
 *x=0;
 i=0x80;
 do
  {
   SCL=0;
   ee_delay();
   SCL=1;
   ee_delay();
   if (SDA) *x=(*x)|i;
   i>>=1;
  }while(i!=0);
}
/******************************************************************************/
void ee_start(void)
{
 TRIS &= 0b11111001;	 /* make SCL and SDA outputs 	*/
 SDA = 0;
 ee_delay();
 SCL = 1;
 ee_delay();
 SDA = 1;
 ee_delay();             /* Stop condition */

 SDA=0;
 ee_delay();             /* Start Condition */
}
/******************************************************************************/
/******************** I2C comms to the DS1775	*******************************/
bit ConfigByteDS1775(byte NewConfig)
{
	/* Returns True if write was successfully acknowledged */
 ee_start();		 			/* Send start sequence */

 ee_byte(WRITE_CONTROL_BYTE);   /* Control byte (WRITE) */ 

 if (ack())
  {
	ConfigError=1;
	return(FALSE); 				/* Test Acknowledge	*/
  } 

 ee_byte(1);					/* Set Data Pointer to Config register */

 if (ack()) 
  {
	ConfigError=2;
	return(FALSE); 		/* Test Acknowledge	*/
  }

 ee_byte(NewConfig);			/* Transmit new Configuration */

 if (ack()) 
  {
	ConfigError=3;
	return(FALSE); 		/* Test Acknowledge	*/
  }

 SCL=0;
 ee_delay(); 
 SDA=0;                  	/* Stop condition */
 TRIS1=0;		 		 	/* SDA OUTPUT     */
 ee_delay();
 SCL = 1;
 ee_delay();
 SDA = 1;
 ee_delay();
 return(TRUE);
}
/******************************************************************************/
bit ReadTemperatureFromDS1775(byte *MSByteRead, byte *LSByteRead)
{
 if(!SetDataPointerDS1775(0))		/* Set the data pointer to Temperature */
  return(FALSE);
 /* Returns True if write was successfully acknowledged */
 ee_start();		 			/* Send start sequence */

 ee_byte(READ_CONTROL_BYTE);   	/* Control byte (READ) */ 

 if (ack()) 
  {
	ReadError=3;
	return(FALSE);
  }

 ee_data(MSByteRead);      		/* Get the data MSbyte */

 MasterAck();					/* Acknowledge the data received */

 ee_data(LSByteRead);      		/* Get the data LSbyte */

 ack();							/* Master NAck */

 SCL=0;                  		/* Stop condition */
 ee_delay();
 SDA=0;
 TRIS1=0;		 				/* SDA OUTPUT	    */
 ee_delay();
 SCL=1;
 ee_delay();
 SDA=1;
 return(TRUE);
}
/******************************************************************************/
bit SetDataPointerDS1775(byte NewDataPointer)
{
 /* Returns True if write was successfully acknowledged */
 ee_start();		 			/* Send start sequence */

 ee_byte(WRITE_CONTROL_BYTE);   /* Control byte (WRITE) */ 

 if (ack()) 
  {
	ReadError=1;
	return(FALSE); 		/* Test Acknowledge	*/
  }

 ee_byte(NewDataPointer);		/* Set Data Pointer to Config register */
 
 if (ack()) 
  {
	ReadError=2;
	return(FALSE); 		/* Test Acknowledge	*/
  }

 SCL=0;
 ee_delay(); 
 SDA=0;                  	/* Stop condition */
 TRIS1=0;		 		 	/* SDA OUTPUT     */
 ee_delay();
 SCL = 1;
 ee_delay();
 SDA = 1;
 ee_delay();
 return(TRUE);
}
/******************************************************************************/
void MasterAck(void)
{
 SCL=0;                 /* Acknowledge 		*/
 ee_delay();
 SDA=0;
 TRIS1=0;				/* SDA Output		*/
 ee_delay();
 SCL=1;
 ee_delay();			
 SCL=0;
}
/******************************************************************************/
/******************** I2C comms to the DS1721	*******************************/
bit ConfigByteDS1721(byte NewConfig)
{
 /* Returns True if write was successfully acknowledged */
 ee_start();		 			/* Send start sequence */

 ee_byte(WRITE_CONTROL_BYTE);   /* Control byte (WRITE) */ 

 if (ack())
  return(FALSE); 				/* Test Acknowledge	*/

 ee_byte(ACCESS_CONFIG);		/* Write Config Command */

 if (ack())
  return(FALSE); 				/* Test Acknowledge	*/

 ee_byte(NewConfig);			/* Write New configuration */

 if (ack())
  return(FALSE); 				/* Test Acknowledge	*/
 
 SCL=0;
 ee_delay(); 
 SDA=0;                  		/* Stop condition */
 TRIS1=0;		 		 		/* SDA OUTPUT     */
 ee_delay();
 SCL = 1;
 ee_delay();
 SDA = 1;
 ee_delay();
 return(TRUE);
}
/******************************************************************************/
bit StartTemperatureConversionDS1721(void)
{
 /* Returns True if write was successfully acknowledged */
 ee_start();		 			/* Send start sequence */

 ee_byte(WRITE_CONTROL_BYTE);   /* Control byte (WRITE) */ 

 if (ack())
  return(FALSE); 				/* Test Acknowledge	*/

 ee_byte(START_TEMP_CONVERT);	/* Write Start Temperature Conversion command */

 if (ack())
  return(FALSE); 				/* Test Acknowledge	*/

 SCL=0;
 ee_delay(); 
 SDA=0;                  		/* Stop condition */
 TRIS1=0;		 		 		/* SDA OUTPUT     */
 ee_delay();
 SCL = 1;
 ee_delay();
 SDA = 1;
 ee_delay();
 return(TRUE);
}
/******************************************************************************/
bit ReadTemperatureConversionStatusDS1721(byte *IsBusy)
{
  /* Returns True if write was successfully acknowledged */
 ee_start();		 			/* Send start sequence */

 ee_byte(WRITE_CONTROL_BYTE);   /* Control byte (WRITE) */ 

 if (ack())
  return(FALSE); 				/* Test Acknowledge	*/

 ee_byte(ACCESS_CONFIG);		/* Write Config Command */

 if (ack())
  return(FALSE); 				/* Test Acknowledge	*/

 ee_RepeatStart();				/* Restart Comms command to read */

 ee_byte(READ_CONTROL_BYTE);	/* Control byte (READ) */

 if (ack())
  return(FALSE); 				/* Test Acknowledge	*/

 ee_data(IsBusy);				/* Get the DS1721 status */

 ack();							/* Master NAck */

 SCL=0;                  		/* Stop condition */
 ee_delay();
 SDA=0;
 TRIS1=0;		 				/* SDA OUTPUT	    */
 ee_delay();
 SCL=1;
 ee_delay();
 SDA=1;
 return(TRUE);
}
/******************************************************************************/
void ee_RepeatStart(void)
{
 SCL = 0;
 ee_delay();
 TRIS &= 0b11111001;	 		/* make SCL and SDA outputs 	*/
 ee_delay();
 SDA = 1;
 ee_delay();
 SCL = 1;
 ee_delay();
 SDA = 0;						/* Restart now! */
}
/******************************************************************************/
bit IsDS1721Busy(void)
{unsigned char cRetries=0, Busy=0;
 
 while(cRetries < 254)
  {								/* Read the DS1721 status */
  	if(ReadTemperatureConversionStatusDS1721(&Busy))
     break;
     else
     cRetries++;
  }
 
 if(cRetries < 254)
  {
    if(Busy & 0x80)				/* Check if DS1721 is still busy */
     return(FALSE);				/* DS1721 is done */
     else
     return(TRUE);				/* DS1721 is still */
  }
  else
  return(TRUE);					/* There was an error reading the status */
}
/******************************************************************************/
bit ReadTemperatureFromDS1721(byte *MSByteRead, byte *LSByteRead)
{
 /* Returns True if write was successfully acknowledged */
 ee_start();		 			/* Send start sequence */

 ee_byte(WRITE_CONTROL_BYTE);   /* Control byte (WRITE) */ 

 if (ack())
  return(FALSE); 				/* Test Acknowledge	*/

 ee_byte(READ_TEMPERATURE);		/* Write READ_TEMPERATURE Command */

 if (ack())
  return(FALSE); 				/* Test Acknowledge	*/

 ee_RepeatStart();				/* Restart Comms command to read */

 ee_byte(READ_CONTROL_BYTE);	/* Control byte (READ) */

 if (ack())
  return(FALSE); 				/* Test Acknowledge	*/

 ee_data(MSByteRead);      		/* Get the data MSbyte */

 MasterAck();					/* Acknowledge the data received */

 ee_data(LSByteRead);      		/* Get the data LSbyte */

 ack();							/* Master NAck */

 SCL=0;                  		/* Stop condition */
 ee_delay();
 SDA=0;
 TRIS1=0;		 				/* SDA OUTPUT	    */
 ee_delay();
 SCL=1;
 ee_delay();
 SDA=1;
 return(TRUE);
}
/******************************************************************************/
