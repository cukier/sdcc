/**********************************************************************
*                            I2C Routines
*
*                    Michael Pearce 26 March 2001
*
* Electronics Workshop, Chemistry Department, University of Canterbury
***********************************************************************
Processors Used So Far: PIC12C50x/67x PIC16C64/74/84/
***********************************************************************
Disclaimer:
The following code has been released so that someone may possibly find
something useful in them. The Author and the company he works for takes
no responsibilty for the use of this code or any damage that may be
caused by using part of all of this code.
***********************************************************************
Overview:
This is the bit bang I2C routines I wrote to work on any PIC device.
These functions are SINGLE MASTER ONLY functions, and are ideal for
communicating with things like E2PROMS, LCD Drivers, ADC Converters etc.

Here is a list of the files:
M_I2C_1.C
TESTI2C.C
TEST_PC.C
TEST_PC.EXE

*************************** M_I2C_1.C **************************
DESCRIPTION:
A complete set of bit banged, software driven I2C routines I
created - and they work!!

Functions are:
char I2C_Send(char Address,char *Data,char Num);
char I2C_Read(char Address,char *Data,char Num);
char i2csendbyte(char byte);
char i2cgetbyte(void);
char i2cgetack(void);
void i2csendack(void);
void i2cdelay(char delay);
void i2cstart(void);
void i2cstop(void);
void i2cclock(void);
char i2creadbit(void);


*************************** TESTI2C.C **************************
DESCRIPTION:
A simple test program that outputs to a PCF8577 I2C LCD driver


*************************** TEST_PC.C **************************
DESCRIPTION:
As above, but a DOS simulation that was used to debug it using
Borland C's debugger.


*************************** TEST_PC.EXE **************************
DESCRIPTION:
The Executable of the above.

********************************************************************/





